#!/bin/bash

#Permissions script


#Part 1 - Banners
echo SUPPPPPPPPPPPPPPP
echo Changing banner


echo "Authorized uses only. All activity may be monitored and reported." > /etc/motd
chown root:root /etc/motd
chmod 644 /etc/motd

echo
echo SUP2
echo 

echo "Authorized uses only. All activity may be monitored and reported." > /etc/issue
chown root:root /etc/issue
chmod 644 /etc/issue


echo
echo SUP3
echo


echo "Authorized uses only. All activity may be monitored and reported." > /etc/issue.net
chown root:root /etc/issue.net
chmod 644 /etc/issue.net




#Part 2

echo "Set /etc/passwd ownership and access permissions"
chown root:root /etc/passwd
chmod 644 /etc/passwd

echo "Set /etc/shadow ownership and access permissions"
chown root:shadow /etc/shadow
chmod 640 /etc/shadow

echo "Set /etc/group ownership and access permissions"
chown root:root /etc/group
chmod 644 /etc/group

echo "Set /etc/gshadow ownership and access permissions"
chown root:shadow /etc/gshadow
chmod 640 /etc/group

echo "Set /etc/security/opasswd ownership and access permissions"
chown root:root /etc/security/opasswd
chmod 600 /etc/security/opasswd

echo "Set /etc/passwd- ownership and access permissions"
chown root:root /etc/passwd-
chmod 600 /etc/passwd-

echo "LOL U MADE IT SO FAR GJJJJJJJ"

echo "Set /etc/shadow- ownership and access permissions"
chown root:root /etc/shadow-
chmod 600 /etc/shadow-

echo "Set /etc/group- ownership and access permissions"
chown root:root /etc/group-
chmod 600 /etc/group-

echo "Set /etc/gshadow- ownership and access permissions"
chown root:root /etc/gshadow-
chmod 600 /etc/gshadow-

# set users umask
sed -i "s/UMASK.*022/UMASK   077/" /etc/login.defs

# set root umask
sed -i "s/#.*umask.*022/umask 077/" /root/.bashrc

echo "HOPE U LIKED MY ECHOOOOOOOS"


