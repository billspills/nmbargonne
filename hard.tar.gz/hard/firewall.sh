#!/bin/bash


#delete firewalld + add iptables

sed -i "s/DefaultZone=.*/DefaultZone=drop/g" /etc/firewalld/firewalld.conf

systemctl stop firewalld.service
systemctl mask firewalld.service
systemctl daemon-reload
yum install iptables-services -y
systemctl enable iptables.service

#Firewall rules

echo "overwriting existing rules to iptables"
cat rules.txt > /etc/sysconfig/iptables


