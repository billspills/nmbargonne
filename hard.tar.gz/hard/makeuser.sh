#!/bin/bash

echo "I hope u fucking entered username and password or this script will not work
"
useradd $1 -p $2

usermod -aG wheel $1

#restricting su
sed -i "s/#.*auth.*required.*pam_wheel\.so/auth required pam_wheel\.so group=wheel debug/" /etc/pam.d/su

#restrict sudo
echo "%wheel  ALL=(ALL:ALL) ALL" >> /etc/sudoers

echo "GOOOOOOOOOOOD BOY"
